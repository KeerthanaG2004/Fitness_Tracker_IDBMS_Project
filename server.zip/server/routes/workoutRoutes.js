// server/routes/workoutRoutes.js
const express = require('express');
const Workout = require('../models/Workout');
const router = express.Router();

// Add a workout
router.post('/workouts', async (req, res) => {
  try {
    const workout = new Workout(req.body);
    await workout.save();
    res.status(201).send(workout);
  } catch (error) {
    res.status(400).send({ error: "Unable to add workout", details: error });
  }
});

// Get all workouts or workouts by date
router.get('/workouts', async (req, res) => {
  const { date } = req.query;
  const query = date ? { date: new Date(date) } : {};

  try {
    const workouts = await Workout.find(query);
    res.status(200).send({ todaysWorkouts: workouts });
  } catch (error) {
    res.status(500).send({ error: "Unable to fetch workouts", details: error });
  }
});

module.exports = router;
