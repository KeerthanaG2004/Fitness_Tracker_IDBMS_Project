const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");
const mongoose = require("mongoose");
const { OAuth2Client } = require("google-auth-library");


dotenv.config(); // Load environment variables

const app = express();
const PORT = process.env.PORT || 8080;
const client = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// Middleware Configuration
const corsOptions = {
  origin: ['http://localhost:3000', 'https://your-app-url.onrender.com'], // Adjust as needed
  methods: ['GET', 'POST', 'PUT', 'DELETE'],
  credentials: true,
};
app.use(cors(corsOptions));
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true }));

// MongoDB Connection
const connectDB = async () => {
  try {
    console.log("Connecting to MongoDB...");
    await mongoose.connect(process.env.MONGODB_URL);
    console.log("Connected to MongoDB");
  } catch (error) {
    console.error("Failed to connect to MongoDB:", error);
  }
};


// Define User Schema and Model
const userSchema = new mongoose.Schema({
  name: String,
  email: String,
  googleId: String,
});
const User = mongoose.model("User", userSchema);

// Define Workout Schema and Model
const workoutSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  date: { type: Date, default: Date.now },
  exercise: String,
  duration: Number,
  caloriesBurned: Number,
});
const Workout = mongoose.model("Workout", workoutSchema);

// Google OAuth Verification Function
async function verify(token) {
  const ticket = await client.verifyIdToken({
    idToken: token,
    audience: process.env.GOOGLE_CLIENT_ID,
  });
  const payload = ticket.getPayload();
  return payload;
}

// Google Sign-In Route
app.post("/auth/google", async (req, res) => {
  const { token } = req.body;
  try {
    const userInfo = await verify(token);
    let user = await User.findOne({ googleId: userInfo.sub });

    if (!user) {
      user = new User({
        name: userInfo.name,
        email: userInfo.email,
        googleId: userInfo.sub,
      });
      await user.save();
    }

    res.status(200).json({ message: "Google sign-in successful", userInfo });
  } catch (error) {
    console.error("Google sign-in error:", error);
    res.status(401).json({ message: "Google sign-in failed" });
  }
});

// Function to Calculate Calories Burned
const calculateCalories = (workoutString, userWeight) => {
  let caloriesBurned = 0;
  if (workoutString.toLowerCase().includes("running")) {
    caloriesBurned = userWeight * 0.05; // Simplified formula
  } else if (workoutString.toLowerCase().includes("cycling")) {
    caloriesBurned = userWeight * 0.03; // Simplified formula
  } else {
    caloriesBurned = 50; // Default
  }
  return caloriesBurned;
};

// Workout Routes
app.post("/api/workouts", async (req, res) => {
  const { workoutString, userWeight, userId, duration } = req.body;

  const caloriesBurned = calculateCalories(workoutString, userWeight);

  const newWorkout = new Workout({
    userId,
    exercise: workoutString,
    duration,
    caloriesBurned,
  });

  try {
    await newWorkout.save();
    res.status(201).json(newWorkout);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

app.get("/api/workouts", async (req, res) => {
  try {
    const { userId } = req.query;
    const workouts = await Workout.find({ userId });
    res.status(200).json(workouts);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Health Check Route
app.get("/", (req, res) => {
  res.status(200).json({ message: "Hello developers from GFG" });
});

// Error Handling Middleware
app.use((err, req, res, next) => {
  const status = err.status || 500;
  const message = err.message || "Something went wrong";
  res.status(status).json({
    success: false,
    status,
    message,
  });
});

// Start Server
const startServer = async () => {
  await connectDB(); // Connect to MongoDB before starting the server
  app.listen(PORT, () => {
    console.log(`Server started on port ${PORT}`);
  });
};

startServer();
