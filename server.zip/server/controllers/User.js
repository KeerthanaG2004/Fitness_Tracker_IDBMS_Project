// src/controllers/workoutController.js

import Workout from "../models/Workout.js"; // Import Workout model only once
import { createError } from "../error.js";  // Import error handling utility

// Function to add workout with parsing, categories, and calories calculation
export const addWorkout = async (req, res, next) => {
  try {
    const userId = req.user?.id;
    const { workoutString } = req.body;
    if (!workoutString) {
      return next(createError(400, "Workout string is missing"));
    }

    // Parse workoutString into individual workouts and categorize
    const eachworkout = workoutString.split(";").map((line) => line.trim());
    const categories = eachworkout.filter((line) => line.startsWith("#"));
    if (categories.length === 0) {
      return next(createError(400, "No categories found in workout string"));
    }

    const parsedWorkouts = [];
    let currentCategory = "";

    for (let line of eachworkout) {
      if (line.startsWith("#")) {
        const parts = line.split("\n").map((part) => part.trim());
        if (parts.length < 5) {
          return next(createError(400, "Workout string is incomplete"));
        }

        currentCategory = parts[0].substring(1).trim();
        const workoutDetails = parseWorkoutLine(parts);

        if (workoutDetails == null) {
          return next(createError(400, "Invalid workout format"));
        }

        workoutDetails.category = currentCategory;
        parsedWorkouts.push(workoutDetails);
      } else {
        return next(createError(400, "Improper workout formatting"));
      }
    }

    for (let workout of parsedWorkouts) {
      workout.caloriesBurned = calculateCaloriesBurnt(workout);
      await Workout.create({ ...workout, user: userId });
    }

    return res.status(201).json({
      message: "Workouts added successfully",
      workouts: parsedWorkouts,
    });
  } catch (err) {
    next(err);
  }
};

// Parse individual workout details
const parseWorkoutLine = (parts) => {
  if (parts.length >= 5) {
    return {
      workoutName: parts[1].substring(1).trim(),
      sets: parseInt(parts[2].split("sets")[0].trim()),
      reps: parseInt(parts[2].split("sets")[1].split("reps")[0].trim()),
      weight: parseFloat(parts[3].split("kg")[0].trim()),
      duration: parseFloat(parts[4].split("min")[0].trim()),
    };
  }
  return null;
};

// Calculate calories burnt
const calculateCaloriesBurnt = (workout) => {
  const durationInMinutes = workout.duration;
  const weightInKg = workout.weight;
  const caloriesPerMinute = 5; // Adjustable factor
  return durationInMinutes * caloriesPerMinute * weightInKg;
};
