// src/pages/YouTubeTutorials.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const YouTubeTutorials = () => {
  const [videos, setVideos] = useState([]);
  const [loading, setLoading] = useState(true);
  const API_KEY = 'AIzaSyCoW2fx_wTghpRaM4WtbbgYHRz7QV8Ziqg'; // Replace with your YouTube API key

  useEffect(() => {
    const fetchVideos = async () => {
      try {
        const response = await axios.get('https://www.googleapis.com/youtube/v3/search', {
          params: {
            part: 'snippet',
            q: 'FITNESS Tutorials', // You can change the search query here
            type: 'video',
            maxResults: 20, // Adjust the number of results
            key: API_KEY,
          },
        });
        setVideos(response.data.items);
      } catch (error) {
        console.error('Error fetching YouTube videos:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchVideos();
  }, [API_KEY]);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div>
      <h1>YouTube Tutorials</h1>
      <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
        {videos.map((video) => (
          <div key={video.id.videoId}>
            <h3>{video.snippet.title}</h3>
            <iframe
              width="560"
              height="315"
              src={`https://www.youtube.com/embed/${video.id.videoId}`}
              title={video.snippet.title}
              frameBorder="0"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            ></iframe>
          </div>
        ))}
      </div>
    </div>
  );
};

export default YouTubeTutorials;
