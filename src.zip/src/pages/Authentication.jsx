import React from "react";
import styled from "styled-components";
import { useSelector, useDispatch } from "react-redux";
import { GoogleOAuthProvider, GoogleLogin } from "@react-oauth/google";
import { logout } from "../redux/actions/authActions";
import LogoImage from "../utils/Images/Logo.png";
import AuthImage from "../utils/Images/AuthImage.jpg";

const Container = styled.div`
  flex: 1;
  height: 100%;
  display: flex;
  background: ${({ theme }) => theme.bg};
  @media (max-width: 700px) {
    flex-direction: column;
  }
`;

const Left = styled.div`
  flex: 1;
  position: relative;
  @media (max-width: 700px) {
    display: none;
  }
`;

const Logo = styled.img`
  position: absolute;
  width: 70px;
  top: 40px;
  left: 60px;
  z-index: 10;
`;

const Image = styled.img`
  position: relative;
  height: 100%;
  width: 100%;
  object-fit: cover;
`;

const Right = styled.div`
  flex: 1;
  position: relative;
  display: flex;
  flex-direction: column;
  padding: 40px;
  gap: 16px;
  align-items: center;
  justify-content: center;
`;

const Text = styled.div`
  font-size: 16px;
  text-align: center;
  color: ${({ theme }) => theme.text_secondary};
  margin-top: 16px;
  @media (max-width: 400px) {
    font-size: 14px;
  }
`;

const TextButton = styled.span`
  color: ${({ theme }) => theme.primary};
  cursor: pointer;
  transition: all 0.3s ease;
  font-weight: 600;
`;

const Authentication = () => {
  const dispatch = useDispatch();
  const user = useSelector((state) => state.auth.user);

  const handleLogout = () => {
    dispatch(logout());
    window.location.href = "/";
  };

  const handleGoogleLoginSuccess = (credentialResponse) => {
    // Assuming you have an action to handle Google sign-in success
    dispatch({ type: "LOGIN_SUCCESS", payload: credentialResponse }); // Dispatch login action
    window.location.href = "/dashboard";
  };

  const handleGoogleLoginError = () => {
    console.error("Google Sign-In failed");
  };

  return (
    <GoogleOAuthProvider clientId="YOUR_GOOGLE_CLIENT_ID">
      <Container>
        <Left>
          <Logo src={LogoImage} />
          <Image src={AuthImage} />
        </Left>
        <Right>
          {user ? (
            <>
              <Text>Welcome, {user.name}!</Text>
              <Text>
                Go to your{" "}
                <TextButton onClick={() => (window.location.href = "/dashboard")}>
                  Dashboard
                </TextButton>
              </Text>
              <TextButton onClick={handleLogout}>Logout</TextButton>
            </>
          ) : (
            <>
              <Text>You are not logged in!</Text>
              <GoogleLogin onSuccess={handleGoogleLoginSuccess} onError={handleGoogleLoginError} />
            </>
          )}
        </Right>
      </Container>
    </GoogleOAuthProvider>
  );
};

export default Authentication;
